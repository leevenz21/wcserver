<template>
    <div class="all">
        <a href="#"><img class="upt" src="../assets/update.jpg" alt="update"></a>
        <br><br>
        <a href="#"><h1>Updates regarding on CoronaVirus</h1></a>
        <p>
            Today’s update spikes anew daily record with 3,527 new cases.
        </p>   
        <hr>
        <br>
        <a href="#"><img class="qua" src="../assets/stay.jpg" alt="quarantine"></a>
        <br><br>
        <a href="#"><h1>Quarantine Measures</h1></a>
        
        <p>
            Quarantine Measure Update on the Philippines.
        </p>
    </div>
</template>