<template>
<div class="all">
          <div class="box">
            <h2>Login</h2>
           
            <form>
                <div class="inputBox">
                    <input type="text" name="username" id="username" required="">
                    <label>Email/Username</label>
                </div>
                
                <div class="inputBox">
                    <input type="password" name="password" id="password" required="">
                    <label>Password</label>
                </div>

                <p class="new" id="notcomp"></p>
                <a href="" class="fpass"><p>Forgot password?</p></a>
                <input type="button" value="Login" id="submit" onclick="validate_login()" style="font-family: Garamond;" />
                <p class="new">Help prevent COVID19!  <a href="index_signup.html" class="fpass">Sign up now >></a></p>
            </form>
        </div>
</div>
</template>

<script>
export default{
  data() {
    return {
      uname: '',
      pass: ''

    }
  },
  methods:{
      loginUser(){
        if (this.uname === '') {
          alert('Please enter your  Username.')
        }
      }
  }
}
</script>