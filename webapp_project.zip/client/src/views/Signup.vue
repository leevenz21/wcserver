<template>
<div class="all">
        <div class="box">
            <h2>Sign up</h2>
            <a href="" class="fpass"><p>Already have an account? Click here.</p></a>
            <form>
                <div class="inputBox">
                    <input type="text" name="Firstname" id="fname" required="">
                    <label>Firstname</label>
                </div>

                <div class="inputBox">
                    <input type="text" name="Lastname" id="lname" required="">
                    <label>Lastname</label>
                </div>

                <div class="inputBox">
                    <input type="text" name="Email" id="age" required="">
                    <label>Age</label>
                </div>

                <div class="inputBox">
                    <input type="text" name="Email" id="gender" required="">
                    <label>Gender</label>
                </div>

                <div class="inputBox">
                    <input type="text" name="Email" id="contact" required="">
                    <label>Contact No.</label>
                </div>

                <div class="inputBox">
                    <input type="text" name="Email" id="email" required="">
                    <label>Email</label>
                </div>
                
                <div class="inputBox">
                    <input type="password" name="password" id="password" required="">
                    <label>Password</label>
                </div>

                <div class="inputBox">
                    <input type="password" name="password" id="cpassword" required="">
                    <label>Confirm Password</label>
                </div>
                <p class="new" id="notmatch"></p>
                <p class="new" id="fill"></p>
                <input type="button" value="Submit" id="submit" onclick="validate_signup()" style="font-family: Garamond;" />
            </form>
        </div>
</div>
</template>

<script>

export default{
  data() {
    return {
      fname:'',
      mname: '',
      lname: '',
      address: '',
      birthdate: '',
      contact: '',
      email: '',
      uname: '',
      pass: ''

    }
  },
  methods:{
      registerUser(){
        if (this.fname === '') {
          alert('Please enter your First Name.')
        }
      }
  }
}
</script>

<style>

</style>