<template>
  <div class="all">
    <h1>CoronaVirus (Covid-19)</h1>
    <hr>
    <p>
      According to World Health Organization Coronavirus disease (COVID-19) is an infectious disease caused by a newly discovered coronavirus.
      Most people who fall sick with COVID-19 will experience mild to moderate symptoms and recover without special treatment.
      Older people, and those with underlying medical problems like cardiovascular disease, diabetes, chronic respiratory disease, 
      and cancer are more likely to develop serious illness.
    </p>

    <h1>❗Practices to keep in mind❗</h1>
    <br>
    <img class="pvt" src="../assets/pvt.jpg" alt="prevention">
  </div>
</template>


