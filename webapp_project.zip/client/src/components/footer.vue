<template>
    
    <footer>
   &copy; 2020 CoronaVirus Information. All rights reserved. All trademarks are property of the WHO and DOH.

</footer>
    
</template>