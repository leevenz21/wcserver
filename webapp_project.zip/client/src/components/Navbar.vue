<template>
<div class="navbar">
  <ul class="nav1">
  <li><a href="/">HOME</a></li>
  <li><a href="/about">ABOUT</a></li>
  <li><a href="/update">UPDATE</a></li>
  <li><a href="/login">LOGIN</a></li>
  <li><a href="/signup">SIGNUP</a></li>
  </ul>
</div>
</template>
